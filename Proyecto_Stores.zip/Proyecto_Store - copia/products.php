<?php
include 'includes/header.php';
include 'config/database.php';

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<h2>Products</h2>
<div class="container">
    <h1>Our Products</h1>
    <div class="product-grid">
        <div class="product">
            <img src="images/product1.jpg" alt="Product 1">
            <h3>Product 1</h3>
            <p>Description of Product 1</p>
            <button>Add to Cart</button>
        </div>
        <div class="product">
            <img src="images/product2.jpg" alt="Product 2">
            <h3>Product 2</h3>
            <p>Description of Product 2</p>
            <button>Add to Cart</button>
        </div>
        <div class="product">
            <img src="images/product3.jpg" alt="Product 3">
            <h3>Product 3</h3>
            <p>Description of Product 3</p>
            <button>Add to Cart</button>
        </div>
        <div class="product">
            <img src="images/product4.jpg" alt="Product 4">
            <h3>Product 4</h3>
            <p>Description of Product 4</p>
            <button>Add to Cart</button>
        </div>
        <!-- Add more products as needed -->
    </div>
</div>
<div class="products">
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="product">
            <img src="images/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
            <h3><?php echo $row['name']; ?></h3>
            <p><?php echo $row['description']; ?></p>
            <p>$<?php echo $row['price']; ?></p>
            <p>$<?php echo $row['quantify']; ?></p>
            <a href="product_detail.php?id=<?php echo $row['id']; ?>">View Details</a>
            <a href="cart.php?action=add&id=<?php echo $row['id']; ?>">Add to Cart</a>
        </div>
    <?php endwhile; ?>
</div>

<?php include 'includes/footer.php'; ?>

