<?php
include 'includes/header.php';
include 'config/database.php';

// Asegurarse de que la conexión a la base de datos esté establecida
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Manejar la acción de agregar al carrito
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $id = (int)$_GET['id']; // Convertir a entero para evitar inyecciones SQL
    $sql = "INSERT INTO cart (product_id, quantity) VALUES ($id, 1) ON DUPLICATE KEY UPDATE quantity = quantity + 1";
    $conn->query($sql);
}

// Manejar la acción de actualizar el carrito
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update' && isset($_POST['quantity'])) {
    $quantities = $_POST['quantity'];
    foreach ($quantities as $id => $quantity) {
        $id = (int)$id; // Convertir a entero
        $quantity = (int)$quantity; // Convertir a entero
        $sql = "UPDATE cart SET quantity=$quantity WHERE product_id=$id";
        $conn->query($sql);
    }
}

// Obtener los productos en el carrito
$sql = "SELECT cart.*, products.name, products.price, products.image FROM cart JOIN products ON cart.product_id = products.id";
$result = $conn->query($sql);
?>

<h2>Shopping Cart</h2>
<form method="post" action="cart.php">
    <input type="hidden" name="action" value="update">
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td>
                    <input type="number" name="quantity[<?php echo $row['product_id']; ?>]" value="<?php echo (int)$row['quantity']; ?>" min="1">
                </td>
                <td>$<?php echo number_format($row['price'], 2); ?></td>
                <td>$<?php echo number_format($row['price'] * $row['quantity'], 2); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    <button type="submit">Update Cart</button>
</form>
<a href="checkout.php">Proceed to Checkout</a>

<?php include 'includes/footer.php'; ?>

