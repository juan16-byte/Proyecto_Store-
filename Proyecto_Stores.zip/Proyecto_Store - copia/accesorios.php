<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accesorios - Plane Store Online</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <h2>Accesorios</h2>
        <div class="product-grid">
        <div class="product">
                <img src="images/3d.jpg" alt="Accesorio 1">
                <h2>Accesorio 1</h2>
                <p>Descripción del accesorio.</p>
                <span class="price">$3</span>
                <button>Comprar</button>
            </div>
            <div class="product">
                <img src="images/Pins.jpg" alt="Accesorio 2">
                <h2>Accesorio 2</h2>
                <p>Descripción del accesorio.</p>
                <button>Comprar</button>
            </div>
            <img src="images/Sensores.jpg" alt="Accesorio 3">
                <h2>Accesorio 2</h2>
                <p>Descripción del accesorio.</p>
                <button>Comprar</button>
            </div>
            <!-- Agrega más productos según sea necesario -->
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="scripts.js"></script>
</body>
</html>
