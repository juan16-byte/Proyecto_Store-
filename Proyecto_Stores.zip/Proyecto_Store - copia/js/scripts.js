$(document).ready(function () {
    // Slider functionality
    let currentSlide = 0;
    const slides = $('.slider img');
    const descriptions = [
        "Slide 1 Description",
        "Slide 2 Description",
        "Slide 3 Description"
    ];

    function showSlide(index) {
        slides.removeClass('active').eq(index).addClass('active');
        $('.slider .description').text(descriptions[index]);
    }

    showSlide(currentSlide);

    $('.slider .nav button').on('click', function () {
        if ($(this).hasClass('prev')) {
            currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        } else {
            currentSlide = (currentSlide + 1) % slides.length;
        }
        showSlide(currentSlide);
    });

    // Entry animation
    $('.intro').addClass('animate__animated animate__fadeInDown');

    // Cart functionality
    let cart = [];

    function addToCart(product) {
        cart.push(product);
        alert('Producto añadido al carrito');
        updateCartDisplay();
    }

    function updateCartDisplay() {
        const cartContents = $('.cart-contents');
        cartContents.empty(); // Clear previous contents
        if (cart.length === 0) {
            cartContents.text('El carrito está vacío.');
        } else {
            cart.forEach((item, index) => {
                cartContents.append('<p>' + (index + 1) + '. ' + item + '</p>');
            });
        }
    }

    // Adding product to cart
    $('.product button').on('click', function() {
        const productName = $(this).data('product');
        addToCart(productName);
    });

    updateCartDisplay(); // Initial cart display
});




