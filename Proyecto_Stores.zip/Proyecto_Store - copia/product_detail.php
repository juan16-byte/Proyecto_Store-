<?php
include 'includes/header.php';
include 'config/database.php';

$id = $_GET['id'];
$sql = "SELECT * FROM products WHERE id=$id";
$result = $conn->query($sql);
$product = $result->fetch_assoc();
?>

<h2><?php echo $product['name']; ?></h2>
<img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
<p><?php echo $product['description']; ?></p>
<p>$<?php echo $product['price']; ?></p>
<a href="cart.php?action=add&id=<?php echo $product['id']; ?>">Add to Cart</a>

<?php include 'includes/footer.php'; ?>
