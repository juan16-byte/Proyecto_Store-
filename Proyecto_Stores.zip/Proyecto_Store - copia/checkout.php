<?php
include 'includes/header.php';
include 'config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sql = "SELECT cart.*, products.price FROM cart JOIN products ON cart.product_id = products.id";
    $result = $conn->query($sql);

    $total = 0;
    $items = [];

    while ($row = $result->fetch_assoc()) {
        $total += $row['price'] * $row['quantity'];
        $items[] = $row;
    }

    $conn->begin_transaction();

    try {
        $sql = "INSERT INTO orders (total) VALUES ($total)";
        $conn->query($sql);
        $order_id = $conn->insert_id;

        foreach ($items as $item) {
            $product_id = $item['product_id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($order_id, $product_id, $quantity, $price)";
            $conn->query($sql);
        }

        $conn->query("DELETE FROM cart");

        $conn->commit();
        echo "<p>Thank you for your purchase! Your order has been placed.</p>";
    } catch (Exception $e) {
        $conn->rollback();
        echo "<p>Sorry, there was an error processing your order. Please try again.</p>";
    }
} else {
    $sql = "SELECT cart.*, products.name, products.price FROM cart JOIN products ON cart.product_id = products.id";
    $result = $conn->query($sql);
    $total = 0;
    $items = [];

    while ($row = $result->fetch_assoc()) {
        $total += $row['price'] * $row['quantity'];
        $items[] = $row;
    }
    ?>

    <h2>Checkout</h2>
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?php echo $item['name']; ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>$<?php echo $item['price']; ?></td>
                <td>$<?php echo $item['price'] * $item['quantity']; ?></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="3"><strong>Total</strong></td>
            <td><strong>$<?php echo $total; ?></strong></td>
        </tr>
    </table>
    <form method="post" action="checkout.php">
        <button type="submit">Place Order</button>
    </form>

    <?php
}
?>

<?php include 'includes/footer.php'; ?>
