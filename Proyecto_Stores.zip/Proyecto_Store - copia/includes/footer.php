<footer>
        <div class="container">
            <p>&copy; 2024 Plane Store Online. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
