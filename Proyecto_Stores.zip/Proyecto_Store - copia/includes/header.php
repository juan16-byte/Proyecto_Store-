<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plane Store Online</title>
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/scripts.js" defer></script>
</head>
<body>
<header>
    <div class="container">
        <div class="logo">
            <a href="index.php"><img src="Logo.jpg" alt="Plane Store Online"></a>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="accesorios.php">Accesorios</a></li>
                <li><a href="revistas.php">Revistas</a></li>
                <li><a href="login.php">Iniciar Sesión</a></li>
                <li><a href="register.php">Registrarse</a></li>
            </ul>
        </nav>
        <div class="search-cart">
            <form action="buscar.php" method="get">
                <input type="text" name="search" placeholder="Buscar...">
                <button type="submit">Buscar</button>
            </form>
            <a href="cart.php" class="cart"><i class="fas fa-shopping-cart"></i><span>0</span></a>
        </div>
    </div>
</header>





