<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plane Store Online</title>
    <link rel="stylesheet" href="styles.css">
  
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <div class="intro">
            <h1>Bienvenidos a Plane Store Online</h1>
        </div>

        <section class="featured-products">
            <h2>Productos Destacados</h2>
            <div class="product-grid">
                <!-- Ejemplo de productos destacados -->
                <div class="product">
                    <img src="images/sensores.jpg" alt="Producto Destacado 1">
                    <h3>Producto Destacado 1</h3>
                    <p>Descripción del producto destacado 1.</p>
                    <button>Comprar</button>
                </div>
                <div class="product">
                    <img src="images/Retro.jpg" alt="Producto Destacado 2">
                    <h3>Producto Destacado 2</h3>
                    <p>Descripción del producto destacado 2.</p>
                    <button>Comprar</button>
                </div>
                <div class="product">
                    <img src="images/Retro.jpg" alt="Producto Destacado 2">
                    <h3>Producto Destacado 2</h3>
                    <p>Descripción del producto destacado 2.</p>
                    <button>Comprar</button>
                </div>
                <div class="product">
                    <img src="images/Retro.jpg" alt="Producto Destacado 2">
                    <h3>Producto Destacado 2</h3>
                    <p>Descripción del producto destacado 2.</p>
                    <button>Comprar</button>
                </div>
                <div class="product">
                    <img src="images/Retro.jpg" alt="Producto Destacado 2">
                    <h3>Producto Destacado 2</h3>
                    <p>Descripción del producto destacado 2.</p>
                    <button>Comprar</button>
                </div>
                
                <!-- Agrega más productos destacados según sea necesario -->
            </div>
        </section>
    
        <div class="slider"><style>/* General styling for the slider */
.slider {
    position: relative;
    width: 400px;  /* Adjust this to your desired width */
    height: 400px;
    margin: auto;
    overflow: hidden;
}

/* Ensure all images have the same size */
.slider img {
    width: 100%;
    height: auto;
    display: none;
}

/* Active image styling */
.slider img.active {
    display: block;
}

/* Navigation buttons styling */
.slider .nav {
    position: absolute;
    top: 50%;
    width: 100%;
    display: flex;
    justify-content: space-between;
    transform: translateY(-50%);
}

.slider .nav button {
    background-color: rgba(0, 0, 0, 0.5);
    border: none;
    color: white;
    padding: 10px;
    cursor: pointer;
}

.slider .nav button:hover {
    background-color: rgba(0, 0, 0, 0.8);
}

/* Description styling */
.slider .description {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    color: white;
    padding: 10px;
    text-align: center;
    width: 80%;  /* Adjust this to your preference */
}
 </style>
    <img src="images/Revista1.jpg" alt="Slide 1" class="active">
    <img src="images/A320.jpg" alt="Slide 2">
    <img src="images/747.jpg" alt="Slide 3">
    <div class="description">Slide 1 Description</div>
    <div class="nav">
        <button class="prev">&lt;</button>
        <button class="next">&gt;</button>
    </div>
</div>
<div class="product">
            <h2>Product 3</h2>
            <button data-product="Product 3">Add to Cart</button>
        </div>
    </div>

    <div class="cart">
        <h2>Shopping Cart</h2>
        <div class="cart-contents">El carrito está vacío.</div>
    </div>
</main>
    <?php include 'includes/footer.php'; ?>

    <script src="scripts.js"></script>
</body>
</html>




