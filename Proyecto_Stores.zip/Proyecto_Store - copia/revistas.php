<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revistas y Libros - Plane Store Online</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <h2>Revistas y Libros</h2>
        <div class="product-grid">
            <div class="product">
                <img src="images/revista1.jpg" alt="Revista 1">
                <h3>Revista 1</h3>
                <p>Descripción de la revista 1.</p>
                <button>Comprar</button>
            </div>
            <div class="product">
                <img src="images/libro1.jpg" alt="Libro 1">
                <h3>Libro 1</h3>
                <p>Descripción del libro 1.</p>
                <button>Comprar</button>
            </div>
            <div class="product">
                <img src="images/revista2.jpg" alt="Revista 2">
                <h3>Revista 2</h3>
                <p>Descripción de la revista 2.</p>
                <button>Comprar</button>
            </div>
            <!-- Agrega más productos según sea necesario -->
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="scripts.js"></script>
</body>
</html>
